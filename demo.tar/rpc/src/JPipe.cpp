/*
 * JPipe.cpp
 *
 *  Created on: Nov 19, 2015
 *      Author: z.j
 */
#include <iostream>
#include "common.h"
#include "JPipe.h"

using namespace std;
using namespace rpc;

JPipe::JPipe() {

}

JPipe::~JPipe() {

}

int JPipe::send() {
    cout << "JPipe send message" << endl;
    return JSUCCESS;
}

int JPipe::recv() {
    cout << "JPipe recv message" << endl;
    return JSUCCESS;
}

