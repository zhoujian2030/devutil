/*
 * JPipe.h
 *
 *  Created on: Nov 19, 2015
 *      Author: z.j
 */
#ifndef _JPIPE_H_
#define _JPIPE_H_

namespace rpc 
{
    class JPipe {
        public:
            JPipe();
            ~JPipe();

            int send();
            int recv();

    };

}

#endif
// end of file