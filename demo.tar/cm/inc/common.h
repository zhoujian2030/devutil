#define JSUCCESS   100
#define JERROR     111