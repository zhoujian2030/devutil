#!/bin/sh

tar xvf test.tar
chmod +x untar.sh
