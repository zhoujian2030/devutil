#define JSUCCESS   1000
#define JERROR     -1


// define for pipe
#define JPIPE_NOT_EMPTY 1101